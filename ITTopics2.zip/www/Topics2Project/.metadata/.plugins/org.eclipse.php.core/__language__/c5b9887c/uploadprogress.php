<?php

// Start of uploadprogress v.1.0.3.1

function uploadprogress_get_info () {}

function uploadprogress_get_contents () {}

// End of uploadprogress v.1.0.3.1
?>
