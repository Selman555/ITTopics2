<div id="status">
    <span>Aangemeld als: </span>
    <?php echo $this->session->userdata('username');?>
</div>
