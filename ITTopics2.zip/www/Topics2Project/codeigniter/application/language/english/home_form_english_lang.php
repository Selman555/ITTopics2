<?php
$lang['home']="Home";
$lang['about']="About";
$lang['prive']="Private files";
$lang['logout']="Log out";
$lang['login']="Login";
$lang['algemeen']="Common";
$lang['inl']="Welkom to our site";
$lang['voorstelling']="Intro";
$lang['leden']="Members";
$lang['verslagen']="Papers";
$lang['to do']="To Do's";
$lang['priveBestandBericht']="You can find all our files like rapports, mockups, etz on this site";
$lang['titelLeden']="PixelApps - Teammembers";
$lang['titelBiografie']="Biography Members";
$lang['functie']="Functions";
$lang['functieBericht']="Put your function here";
$lang['specialiteit']="Specialities";
$lang['specialiteitBericht']="Your specialities";
$lang['hobbie']="Hobby's";
$lang['hobbieBericht']="Your hobbies";
$lang["aboutHoofdTitel"]="A short summary of our ICT Project";
$lang["aboutOmschrijvingTitle"]="A short summary of the content from our project ";
$lang['loginGebruiker']="Username";
$lang['loginPassword']="Password";
$lang['loginGebruikerTitel']="Give your username and password";
$lang['paswoordGebruikerTitel']="Give your username, your old password and your new password";
$lang['loginPasswordTitel']="Forgotten your password";
$lang['LoginbtnAanmelden']="Login";
$lang['paswoordbtnReset']="Reset";
$lang['LoginPasswoord']="recover it here";
$lang['loginMeldingIngelogd']="You have to be logged in to view this content.";
$lang['loginMeldingNietIngelogd']="Please login by following ";
$lang['loginMeldingNietIngelogd2']="this link.";
$lang['profileTitle']="Profile overview";
$lang['email']="Your e-mail addres";
$lang['reset']="Change this setting";
$lang['mailNew']="New e-mail";
$lang['mailConfirm']="Confirm new e-mail";
$lang['passwordresettitle']="Reset your password";
$lang['passwordOld']="Old password";
$lang['passwordNew']="New password";
$lang['passwordConfirm']="Confirm password";
$lang['LoginbtnPasswoord']="Password&nbsp;forgotten?";
//contact page
$lang['ContactTitel']="Contact us";
$lang['ContactName']="Name";
$lang['ContactEmail']="Email";
$lang['ContactMessage']="Message";
//contactverzonden
$lang['ContactMessage']="Your message has been send to us";
$lang['ContactMessage2']=" Thank you for contacting";
//password recovery
$lang['loginEmail']='Email address';

?>