<?php
//Profielpagina meldingen
$lang['emailChanged']="Your e-mail address has been updated.";
$lang['passwordChanged']="Your password has been updated.";
$lang['webserviceError']="The webservice could not process your request";
$lang['passwordIncorrect']="Your password was incorrect.";
$lang['passwordMatch']="The password fields did not match.";
$lang['emailMatch']="The e-mail addresses did not match.";
$lang['unauthorized']="You could not be authorized.";
$lang['fieldsIncorrect']="Please fill in all fields with valid values.";
//Contactpagina meldingen
$lang['ContactError']="The reCAPTCHA wasn't entered correctly. Try it again, please.";
//loginpagina meldingen
$lang['loginError']="Wrong password or username";
?>
