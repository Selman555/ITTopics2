<?php

$lang['home']="Home";
$lang['about']="Over ons";
$lang['prive']="Priv&eacute bestanden";
$lang['logout']="Afmelden";
$lang['login']="Aanmelden";
$lang['password']="Paswoord opnieuw instellen";
$lang['algemeen']="Algemeen";
$lang['inl']="Welkom bij";
$lang['voorstelling']="Voortelling";
$lang['leden']="Leden";
$lang['verslagen']="Verslagen";
$lang['to do']="Te doen";
$lang['priveBestandBericht']="Hier kan u al onze bestanden zoals verslagen, mock-ups, enz.";
$lang['titelLeden']="PixelApps - Groepsleden";
$lang['titelBiografie']="Biografie Groepsleden";
$lang['functie']="Functies";
$lang['functieBericht']="Functie hier";
$lang['specialiteit']="Gerelateerde Specialiteiten";
$lang['specialiteitBericht']="Specialiteiten hier";
$lang['hobbie']="Hobbies";
$lang['hobbieBericht']="hobbies hier";
$lang["aboutHoofdTitel"]="Een korte samenvatting van ons ICT Project";
$lang["aboutOpdrachtgeverTitel"]="Voorstelling Opdrachtgever";
$lang["aboutWaaromTitel"]="Waarom we deze opdracht gekozen hebben";
$lang["aboutOmschrijvingTitle"]="Korte omschrijving van onze opdracht";
$lang['loginGebruiker']="Gebruikersnaam";
$lang['loginPassword']="Paswoord";
$lang['loginGebruikerTitel']="Geef hier uw gebruikersnaam en paswoord in";
$lang['paswoordGebruikerTitel']="Geef uw gebruikersnaam, uw nieuw en uw oud paswoord in";
$lang['loginPasswordTitel']="Bent u uw paswoord vergeten?";
$lang['LoginbtnAanmelden']="Aanmelden";
$lang['paswoordbtnReset']="Instellen";
$lang['LoginPasswoord']="paswoord ophalen";
$lang['loginMeldingIngelogd']="U moet aangemeld zijn om deze inhoud te zien";
$lang['loginMeldingNietIngelogd']="Gelieve u eerst ";
$lang['loginMeldingNietIngelogd2']="hier aan te melden.";
$lang['profileTitle']="Profiel overzicht";
$lang['email']="Uw e-mail adres";
$lang['reset']="Opnieuw instellen";
$lang['mailNew']="Nieuw";
$lang['mailConfirm']="Bevestig";
$lang['passwordresettitle']="Uw paswoord opnieuw instellen";
$lang['passwordOld']="Oud paswoord";
$lang['passwordNew']="Nieuw paswoord";
$lang['passwordConfirm']="Bevestig paswoord";
$lang['LoginbtnPasswoord']="Paswoord&nbsp;vergeten?";
$lang['ContactTitel']="Contacteer ons";
$lang['ContactName']="Naam";
$lang['ContactEmail']="Email";
$lang['ContactMessage']="Boodschap";
//contactverzonden
$lang['ContactMessage']="Uw boodschap werd naar ons gestuurd";
$lang['ContactMessage2']="Bedankt voor uw reactie.";
//password recovery
$lang['loginEmail']='Email adres';

?>
