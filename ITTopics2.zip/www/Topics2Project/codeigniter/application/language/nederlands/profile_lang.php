<?php
//Profielpagina meldingen
$lang['emailChanged']="Uw e-mail adres is veranderd.";
$lang['passwordChanged']="Uw paswoord is veranderd.";
$lang['webserviceError']="De webservice kon uw aanvraag niet verwerken";
$lang['passwordIncorrect']="Uw paswoord was niet correct.";
$lang['passwordMatch']="De paswoorden komen niet overeen.";
$lang['emailMatch']="De e-mail adressen komen niet overeen.";
$lang['unauthorized']="U kon niet worden geauthoriseerd.";
$lang['fieldsIncorrect']="Gelieve alle velden met een geldige waarde in te vullen.";
$lang['ContactError']="De reCAPTCHA is niet goed ingegeven. Gelieve opnieuw te proberen";
//passwordrecovery pagina meldeingen
$lang['PasswordError']="Uw email adres bevindt zich niet in onze database";
//loginpagina meldingen
$lang['loginError']="Verkeerd paswoord of gebruikersnaam";
?>
